var usrbase = [];


function createObj(username, password) {
    obj = {
        username: username,
        password: password
    };
    return obj;
}

function register() {
    var user = document.forms["regform"]["reguser"].value;
    var password = document.forms["regform"]["regpassword"].value;
    var verify = document.forms["regform"]["regpassverify"].value;
    document.forms["regform"]["reguser"].value = "";
    document.forms["regform"]["regpassword"].value = "";
    document.forms["regform"]["regpassverify"].value = "";
    for (var i = 0; i < usrbase.length; i++) {
        console.log("got into username check for loop");
        if (user == usrbase[i].username) {
            console.log("got into username check if");
            document.getElementById("regmsg").style.color = 'red';
            return document.getElementById("regmsg").innerHTML = "Username taken";
        }
    }
    if (user == "" && password == "") {
        console.log("got into username check if");
        document.getElementById("regmsg").style.color = 'red';
        document.getElementById("regmsg").innerHTML = "Username and password required";
    } else if (user == "") {
        document.getElementById("regmsg").style.color = 'red';
        document.getElementById("regmsg").innerHTML = "Username required";
    } else if (password == "") {
        document.getElementById("regmsg").style.color = 'red';
        document.getElementById("regmsg").innerHTML = "Password required";
    } else if (password !== verify) {
        document.getElementById("regmsg").style.color = 'red';
        document.getElementById("regmsg").innerHTML = "Passwords do not match";
    } else {
        usrbase.push(createObj(user, password));
        document.getElementById("regmsg").style.color = 'black';
        document.getElementById("regmsg").innerHTML = "Register successful";
    }
    console.log(usrbase[usrbase.length - 1]);
    console.log(usrbase.length);
}


function login() {
    var notifydone = 0;
    var user = document.forms["logform"]["loguser"].value;
    var password = document.forms["logform"]["logpassword"].value;
    document.forms["logform"]["loguser"].value = "";
    document.forms["logform"]["logpassword"].value = "";
    //this part exists only for the case a login is tried before theres members
    if (user == "" && password == "") {
        document.getElementById("logmsg").style.color = 'red';
        document.getElementById("logmsg").innerHTML = "Username and password required";

        notifydone = true;
    }
    //this part exists only for the case a login is tried before theres members
    if (notifydone == false){
    for (var i = 0; i < usrbase.length; i++) {
        if (user == "" && password == "") {
            document.getElementById("logmsg").style.color = 'red';
            document.getElementById("logmsg").innerHTML = "Username and password required";

        } else if (user == "") {
            document.getElementById("logmsg").style.color = 'red';
            document.getElementById("logmsg").innerHTML = "Username required";
        } else if (password == "") {
            document.getElementById("logmsg").style.color = 'red';
            document.getElementById("logmsg").innerHTML = "Password required";
        } else if (user == usrbase[i].username && password == usrbase[i].password) {
            document.getElementById("logmsg").style.color = 'black';
            document.getElementById("logmsg").innerHTML = "Welcome " + usrbase[i].username + ".";
            console.log("it did the login thing");
            break;
        } else {
            document.getElementById("logmsg").style.color = 'red';
            document.getElementById("logmsg").innerHTML = "Wrong username/password";
        }
    }
}
}

function remove() {
    var notifydone = false;
    var user = document.forms["remform"]["remuser"].value;
    var password = document.forms["remform"]["rempassword"].value;
    document.forms["remform"]["remuser"].value = "";
    document.forms["remform"]["rempassword"].value = "";
    //this part exists only for the case a remove is tried before theres members
    if (user == "" && password == "") {
        document.getElementById("logmsgremove").style.color = 'red';
        document.getElementById("logmsgremove").innerHTML = "Username and password required";
        notifydone = true;
    }
    //this part exists only for the case a remove is tried before theres members
    if (notifydone == false){
    for (var i = 0; i < usrbase.length; i++) {
        if (user == "" && password == "") {
            document.getElementById("logmsgremove").style.color = 'red';
            document.getElementById("logmsgremove").innerHTML = "Username and password required";
        } else if (user == "") {
            document.getElementById("logmsgremove").style.color = 'red';
            document.getElementById("logmsgremove").innerHTML = "Username required";
        } else if (password == "") {
            document.getElementById("logmsgremove").style.color = 'red';
            document.getElementById("logmsgremove").innerHTML = "Password required";
        } else if (user == usrbase[i].username && password == usrbase[i].password) {
            usrbase.splice(i,1);
            document.getElementById("logmsgremove").style.color = 'black';
            document.getElementById("logmsgremove").innerHTML = "User removed";
            break;
        } else {
            document.getElementById("logmsgremove").style.color = 'red';
            document.getElementById("logmsgremove").innerHTML = "Wrong username/password";
        }
    }
    }
}