var usrbase = [];

function loadbackup(){
    var backup = JSON.parse(localStorage.getItem("userbase"));
    if(backup != null){
        usrbase = backup;
    }
}
loadbackup();

function createObj(username, password, grades) {
    obj = {
        username: username,
        password: password,
        grades: grades
    };
    return obj;
}

function avg(grades) {
    var memuza = 0;
    for (var i = 0; i < grades.length; i++) {
        memuza += grades[i];
    }
    console.log(memuza);
    return memuza / grades.length;
}

function strtonum(stringarr) {
    for (var j = 0; j < stringarr.length; j++) {
        stringarr[j] = Number(stringarr[j]);
    }
    return stringarr;
}

function register() {
    var user = document.forms["tofes"]["user"].value;
    var password = document.forms["tofes"]["password"].value;
    var gradesraw = document.forms["tofes"]["grades"].value;
    var gradessorted = gradesraw.split(",");
    gradessorted = strtonum(gradessorted);
    console.log(gradessorted);
    for (var i = 0; i < usrbase.length; i++) {
        console.log("got into username check for loop");
        if (user == usrbase[i].username) {
            console.log("got into username check if");
            return document.getElementById("regmsg").innerHTML = "Username taken";
        }
    }
    if (user == "" && password == "") {
        document.getElementById("regmsg").innerHTML = "Username and password required";
    }
    else if (user == "") {
        document.getElementById("regmsg").innerHTML = "Username required";
    }
    else if (password == "") {
        document.getElementById("regmsg").innerHTML = "Password required";
    }
    else {
        usrbase.push(createObj(user, password, gradessorted));
        localStorage.setItem("userbase", JSON.stringify(usrbase));
        console.log(usrbase);
        document.getElementById("regmsg").innerHTML = "Register successful";
    }
}

function checkpass() {
    var passed = [];
    var minscore = document.forms["tofes2"]["minavg"].value;
    for (var i = 0; i < usrbase.length; i++) {
        if (avg(usrbase[i].grades) > minscore) {
            passed.push(usrbase[i].username);
        }
        else {

        }
    }
    document.getElementById("regmsg2").innerHTML = passed;
}