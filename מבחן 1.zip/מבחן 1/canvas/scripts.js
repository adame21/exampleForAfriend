//this is to make it all over
var canvas = document.querySelector('canvas');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

//other canvas stuff
//gives c the ability to draw in 2d
var c = canvas.getContext('2d')
//draws a bunch of squares with this format - x, y, width, height (draws like a giant square brush kinda)
c.fillStyle = "darkgreen";
c.fillRect(100, 200, 400, 400);
c.fillStyle = "lightgreen";
c.fillRect(100, 100, 100, 100);
c.fillRect(400, 100, 100, 100);
c.fillStyle = "#ecffbc"
c.fillRect(115, 215, 370,370);

// drawing a line
//this makes it seperate to other drawings
c.beginPath();
// takes x and y 
//initialize the point
c.moveTo(900, 300);
//tell it where to go
c.lineTo(600, 100);
c.lineTo(800, 600);
c.lineTo(900, 300);
//add color
c.strokeStyle = "blue";
//makes it draw
c.stroke();

//arc/circle
c.beginPath();
c.arc(700,800, 40, 0, Math.PI * 2, false);
c.strokeStyle = 'purple';
c.stroke();


//making stuff with a for loop
for(var i = 0; i< 10000; i++){
    var x = Math.random() * window.innerWidth; //stores in x a random number between 0-1 and multiply by the window to adjust the position of the circles
    var y = Math.random() * window.innerHeight;
    c.beginPath();
    c.arc(x,y, 40, 0, Math.PI * 2, false);
    c.strokeStyle = 'purple';
    c.stroke();
}