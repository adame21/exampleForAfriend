var usrbase = [];

function createObj(username, password, grades) {
    obj = {
        username: username,
        password: password,
        grades: grades
    };
    return obj;
}

function avg(grades) {
    var memuza = 0;
    for (var i = 0; i < grades.length; i++) {
        memuza += grades[i];
    }
    console.log(memuza);
    return memuza / grades.length;
}

function strtonum(stringarr) {
    for (var j = 0; j < stringarr.length; j++) {
        stringarr[j] = Number(stringarr[j]);
    }
    return stringarr;
}

function register() {
    var user = document.forms["regform"]["user"].value;
    var password = document.forms["regform"]["password"].value;
    var gradesraw = document.forms["regform"]["grades"].value;
    document.forms["regform"]["user"].value = "";
    document.forms["regform"]["password"].value = "";
    document.forms["regform"]["grades"].value = "";
    var gradessorted = gradesraw.split(",");
    gradessorted = strtonum(gradessorted);
    console.log(gradessorted);
    for (var i = 0; i < usrbase.length; i++) {
        console.log("got into username check for loop");
        if (user == usrbase[i].username) {
            console.log("got into username check if");
            document.getElementById("regmsg").style.color = 'red';
            return document.getElementById("regmsg").innerHTML = "Username taken";
        }
    }
    if (user == "" && password == "") {
        document.getElementById("regmsg").style.color = 'red';
        document.getElementById("regmsg").innerHTML = "Username and password required";
    }
    else if (user == "") {
        document.getElementById("regmsg").style.color = 'red';
        document.getElementById("regmsg").innerHTML = "Username required";
    }
    else if (password == "") {
        document.getElementById("regmsg").style.color = 'red';
        document.getElementById("regmsg").innerHTML = "Password required";
    }
    else {
        usrbase.push(createObj(user, password, gradessorted));
        console.log(usrbase);
        document.getElementById("regmsg").style.color = 'black';
        document.getElementById("regmsg").innerHTML = "Register successful";
    }
}

function checkpass() {
    var passed = [];
    var minscore = document.forms["testform"]["minavg"].value;
    document.forms["testform"]["minavg"].value = "";
    for (var i = 0; i < usrbase.length; i++) {
        if (avg(usrbase[i].grades) > minscore) {
            passed.push(usrbase[i].username);
        }
    }
    document.getElementById("regmsg2").innerHTML ="Students with a passing score: " + passed;
}